package com.tns.onlineshopping.entities;

public class Admin {

	private String adminId;
	private String username;
	private String email;
	
	public Admin(String adminId, String username, String email) {
		this.adminId = adminId;
		this.username = username;
		this.email = email;
	}
	
	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Admin [Admin ID=" + adminId + ", Username=" + username + ", Email=" + email + "]";
	}

	
	}

	




