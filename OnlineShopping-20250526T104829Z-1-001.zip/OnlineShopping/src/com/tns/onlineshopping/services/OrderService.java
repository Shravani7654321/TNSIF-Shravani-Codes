package com.tns.onlineshopping.services;

import java.util.ArrayList;
import java.util.List;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.tns.onlineshopping.entities.Customer;
import com.tns.onlineshopping.entities.Order;

public class OrderService {
    private List<Order> orderList = new ArrayList<>();

    public void placeOrder(Scanner scanner, CustomerService customerService) {
        try {
            System.out.print("Enter Order ID: ");
            int orderId = scanner.nextInt();

            System.out.print("Enter Customer ID: ");
            int customerId = scanner.nextInt();

            // Retrieve the Customer object using CustomerService
            Customer customer = customerService.getCustomer(customerId);

            if (customer == null) {
                System.out.println("Customer not found! Order cannot be placed.");
                return;
            }

            Order order = new Order(orderId, customer, new ArrayList<>(), "Pending");
            orderList.add(order);
            System.out.println("Order placed successfully!");
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Clear the buffer
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while placing an order: " + e.getMessage());
        }
    }

    public void updateOrderStatus(Scanner scanner) {
        try {
            System.out.print("Enter Order ID: ");
            int orderId = scanner.nextInt();
            scanner.nextLine(); 

            Order order = getOrder(orderId);
            if (order == null) {
                System.out.println("Invalid Order ID. No such order exists.");
                return;
            }

            System.out.println("Enter new status (Completed/Delivered/Cancelled): ");
            String status = scanner.nextLine().trim(); 

            if (status.isEmpty()) {
                throw new IllegalArgumentException("Status cannot be empty.");
            }

            order.setStatus(status);
            System.out.println("Order status updated to: " + status);
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter a valid number.");
            scanner.nextLine(); // Clear the buffer
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while updating order status: " + e.getMessage());
        }
    }

    public Order getOrder(int orderId) {
        try {
            return orderList.stream().filter(order -> order.getOrderId() == orderId).findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Order with ID " + orderId + " not found."));
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while retrieving an order: " + e.getMessage());
            return null;
        }
    }

    public void viewOrders() {
        try {
            if (orderList.isEmpty()) {
                System.out.println("No orders found.");
            } else {
                System.out.println("Orders:");
                for (Order order : orderList) {
                    System.out.println(order);
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred while displaying orders: " + e.getMessage());
        }
    }
}


