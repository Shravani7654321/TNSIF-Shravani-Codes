package com.tns.onlineshopping.services;

import java.util.ArrayList;
import java.util.List;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.tns.onlineshopping.entities.Admin;

public class AdminService {
    private List<Admin> adminList = new ArrayList<>();

    // Add admin 
    public void addAdmin(Admin admin) {
        try {
            if (admin == null) {
                throw new IllegalArgumentException("Admin cannot be null.");
            }
            
            for (Admin existingAdmin : adminList) {
                if (existingAdmin.getAdminId().equals(admin.getAdminId())) {
                    throw new IllegalArgumentException("Admin with ID " + admin.getAdminId() + " already exists.");
                }
            }
            
            adminList.add(admin);
            System.out.println("Admin added successfully!");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while adding admin: " + e.getMessage());
        }
    }

    public List<Admin> getAdmins() {
        return adminList;
    }

    // Create an admin 
    public void createAdmin(Scanner scanner) {
        try {
            System.out.print("Enter Admin ID: ");
            String adminId = scanner.next();
            System.out.print("Enter Admin Username: ");
            String username = scanner.next();
            System.out.print("Enter Admin Email: ");
            String email = scanner.next();
            
            if (adminId.isEmpty() || username.isEmpty() || email.isEmpty()) {
                throw new IllegalArgumentException("Admin details cannot be empty.");
            }
            
            Admin admin = new Admin(adminId, username, email);
            addAdmin(admin);
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter correct values.");
            scanner.nextLine(); // Clear buffer
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    // View admins
    public void viewAdmins() {
        try {
            if (adminList.isEmpty()) {
                System.out.println("No admins found.");
            } else {
                System.out.println("Admins:");
                for (Admin admin : adminList) {
                    System.out.println(admin);
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred while displaying admins: " + e.getMessage());
        }
    }
}

