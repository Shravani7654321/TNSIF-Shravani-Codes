package com.tns.onlineshopping.services;

import java.util.ArrayList;
import java.util.List;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.tns.onlineshopping.entities.Customer;
import com.tns.onlineshopping.entities.Order;
import com.tns.onlineshopping.entities.ShoppingCart;

public class CustomerService {
    private List<Customer> customerList = new ArrayList<>();

    public void addCustomer(Customer customer) {
        try {
            if (customer == null) {
                throw new IllegalArgumentException("Customer cannot be null.");
            }
            customerList.add(customer);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while adding a customer: " + e.getMessage());
        }
    }

    public Customer getCustomer(int userId) {
        try {
            return customerList.stream()
                    .filter(customer -> customer.getUserId() == userId)
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Customer with User ID " + userId + " not found."));
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while retrieving a customer: " + e.getMessage());
            return null;
        }
    }

    public void viewCustomers() {
        try {
            if (customerList.isEmpty()) {
                System.out.println("No customers found.");
            } else {
                System.out.println("Customers:");
                for (Customer customer : customerList) {
                    System.out.println("User ID: " + customer.getUserId() +
                            ", Username: " + customer.getUsername() +
                            ", Email: " + customer.getEmail() +
                            ", Address: " + customer.getAddress());
                }
            }
        } catch (Exception e) {
            System.out.println("An error occurred while displaying customers: " + e.getMessage());
        }
    }

    public void createCustomer(Scanner scanner) {
        try {
            System.out.print("Enter User ID: ");
            int userId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter Username: ");
            String username = scanner.nextLine();
            System.out.print("Enter Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter Address: ");
            String address = scanner.nextLine();
            
            if (username.isEmpty() || email.isEmpty() || address.isEmpty()) {
                throw new IllegalArgumentException("Customer details cannot be empty.");
            }
            
            Customer customer = new Customer(userId, username, email, address, new ShoppingCart(), new ArrayList<>());
            addCustomer(customer);
            System.out.println("Customer created successfully!");
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter correct values.");
            scanner.nextLine(); // Clear buffer
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    public void viewOrders() {
        try {
            boolean hasOrders = false;
            for (Customer customer : customerList) {
                List<Order> orders = customer.getOrders();
                if (!orders.isEmpty()) {
                    hasOrders = true;
                    System.out.println("\nOrders for " + customer.getUsername() + ":");
                    for (Order order : orders) {
                        System.out.println(order);
                    }
                }
            }
            if (!hasOrders) {
                System.out.println("No orders found.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred while viewing orders: " + e.getMessage());
        }
    }
}