package com.tns.onlineshopping.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.tns.onlineshopping.entities.Product;

public class ProductService {
    private List<Product> productList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    // Method to take user input and add a product
    public void addProduct() {
        try {
            System.out.print("Enter Product ID: ");
            int productId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter Product Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Product Price: ");
            double price = scanner.nextDouble();

            System.out.print("Enter Stock Quantity: ");
            int stockQuantity = scanner.nextInt();

            // Creating product and adding it to the list
            Product product = new Product(productId, name, price, stockQuantity);
            productList.add(product);
            System.out.println("Product added successfully!");
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter the correct data type.");
            scanner.nextLine(); 
        } catch (Exception e) {
            System.out.println("An error occurred while adding the product: " + e.getMessage());
        }
    }

    public void removeProduct() {
        try {
            System.out.print("Enter Product ID to remove: ");
            int productId = scanner.nextInt();

            Iterator<Product> iterator = productList.iterator();
            boolean found = false;

            while (iterator.hasNext()) {
                Product product = iterator.next();
                if (product.getProductId() == productId) {
                    iterator.remove();
                    found = true;
                    System.out.println("Product removed successfully!");
                    break;
                }
            }

            if (!found) {
                System.out.println("Product not found.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter a valid Product ID.");
            scanner.nextLine(); // Clear scanner buffer
        } catch (Exception e) {
            System.out.println("An error occurred while removing the product: " + e.getMessage());
        }
    }

    // Method to display all products
    public void viewProducts() {
        if (productList.isEmpty()) {
            System.out.println("No products available.");
        } else {
            System.out.println("Available Products:");
            for (Product product : productList) {
                System.out.println(product);
            }
        }
    }
    
    public Product getProductById(int productId) {
        return productList.stream()
            .filter(product -> product.getProductId() == productId)
            .findFirst()
            .orElse(null);
    }
}
